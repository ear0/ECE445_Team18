 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.0
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"

/*
    Main application
*/
#define NUM_PTS (128)
#define DESIRED_FREQ (1000)
#define DAC_SET (1)
#define DAC_CLEAR (0)

const uint16_t TRI_LUT[NUM_PTS] =
{
    0x0, 0xf, 0x1f, 0x2f, 0x3f, 0x4f, 0x5f, 0x6f, 0x7f, 0x8f, 0x9f, 0xaf, 0xbf, 
    0xcf, 0xdf, 0xef, 0xff, 0x10f, 0x11f, 0x12f, 0x13f, 0x14f, 0x15f, 0x16f, 0x17f, 
    0x18f, 0x19f, 0x1af, 0x1bf, 0x1cf, 0x1df, 0x1ef, 0x1ff, 0x20f, 0x21f, 0x22f, 
    0x23f, 0x24f, 0x25f, 0x26f, 0x27f, 0x28f, 0x29f, 0x2af, 0x2bf, 0x2cf, 0x2df, 
    0x2ef, 0x2ff, 0x30f, 0x31f, 0x32f, 0x33f, 0x34f, 0x35f, 0x36f, 0x37f, 0x38f, 
    0x39f, 0x3af, 0x3bf, 0x3cf, 0x3df, 0x3ef, 0x3ff, 0x3ef, 0x3df, 0x3cf, 0x3bf, 
    0x3af, 0x39f, 0x38f, 0x37f, 0x36f, 0x35f, 0x34f, 0x33f, 0x32f, 0x31f, 0x30f, 
    0x2ff, 0x2ef, 0x2df, 0x2cf, 0x2bf, 0x2af, 0x29f, 0x28f, 0x27f, 0x26f, 0x25f, 
    0x24f, 0x23f, 0x22f, 0x21f, 0x20f, 0x1ff, 0x1ef, 0x1df, 0x1cf, 0x1bf, 0x1af, 
    0x19f, 0x18f, 0x17f, 0x16f, 0x15f, 0x14f, 0x13f, 0x12f, 0x11f, 0x10f, 0xff, 
    0xef, 0xdf, 0xcf, 0xbf, 0xaf, 0x9f, 0x8f, 0x7f, 0x6f, 0x5f, 0x4f, 0x3f, 0x2f, 
    0x1f, 0xf
};
uint8_t index = 0;
uint8_t dacUpdateFlag = DAC_CLEAR;

void TmrUserInterruptHandler(void) 
{
    //the period of the timer and number of points in the waveform will determine the frequency of the generated waveform
    dacUpdateFlag = DAC_SET;
}

void UpdateDac(void)
{
    if(dacUpdateFlag == DAC_SET)
    {
        DAC1_SetOutput(TRI_LUT[index]);
        index ++;
        if(index > NUM_PTS - 1)
        {
            index = (uint8_t)0x0;
        }
        dacUpdateFlag = DAC_CLEAR;
    }
    
}


int main(void)
{
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts 
    // Use the following macros to: 

    // Enable the Global High Interrupts 
    INTERRUPT_GlobalInterruptHighEnable(); 

    // Disable the Global High Interrupts 
    //INTERRUPT_GlobalInterruptHighDisable(); 

    // Enable the Global Low Interrupts 
    INTERRUPT_GlobalInterruptLowEnable(); 

    // Disable the Global Low Interrupts 
    //INTERRUPT_GlobalInterruptLowDisable(); 
    
    Timer2.TimeoutCallbackRegister(TmrUserInterruptHandler);

    while(1)
    {
        UpdateDac();
    }    
}