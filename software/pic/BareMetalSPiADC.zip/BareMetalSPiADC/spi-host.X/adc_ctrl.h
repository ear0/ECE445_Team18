/* 
 * File:   adc_ctrl.h
 * Author: ellio
 *
 * Created on April 17, 2024, 10:04 PM
 */

#ifndef ADC_CTRL_H
//#define	ADC_CTRL_H
//
//#ifdef	__cplusplus
//extern "C" {
//#endif
//
//
//
//
//#ifdef	__cplusplus
//}
//#endif

void ADC_INIT(void);

#endif	/* ADC_CTRL_H */

