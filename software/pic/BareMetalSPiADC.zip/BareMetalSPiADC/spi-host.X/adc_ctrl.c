#include <xc.h>
#include "adc_ctrl.h"

void ADC_INIT(void)
{
    ADCON0bits.IC = 0; //enable SE mode
    ADCON0bits.FM = 1; // IC=0 and FM =1 for right justified
    ADCON0bits.CS = 1;
    ADREFbits.PREF = 0;
    ADPCH = 0x01;
    ADNCH = 0x10;
    TRISAbits.TRISA1 = 1; 
    TRISAbits.TRISA2 = 1;
    ANSELAbits.ANSELA1 = 1;
    ANSELAbits.ANSELA2 = 1;
    ADACQ = 32; 
    ADCON0bits.ON = 1; 
}
