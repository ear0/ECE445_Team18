//#include "mcc_generated_files/mcc.h"
//
//#include "ff.h"
//
//FATFS fatFs; /* FatFs work area needed for each volume */
//
//FIL file; /* File object needed for each open file */
//
//void blink_led(){
//
//    IO_RA1_Toggle();
//
//}
//
///*
//
//                         Main application
//
// */
//
//void main(void)
//
//{
//
//    UINT bw;
//
//    // Initialize the device
//
//    SYSTEM_Initialize();
//
//    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
//
//    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
//
//    // Use the following macros to:
//
//    // Enable the Global Interrupts
//
//    INTERRUPT_GlobalInterruptEnable();
//
//    // Disable the Global Interrupts
//
//    //INTERRUPT_GlobalInterruptDisable();
//
//    // Enable the Peripheral Interrupts
//
//    INTERRUPT_PeripheralInterruptEnable();
//
//    // Disable the Peripheral Interrupts
//
//    //INTERRUPT_PeripheralInterruptDisable();
//
//    TMR0_SetInterruptHandler(blink_led);
//
//    TMR0_StartTimer();
//
//    SD_LED_SetLow();
//
//    printf("##########################################################\r\n");
//
//    printf("SD Interface with PIC18\r\n");
//
//    printf("##########################################################\r\n");
//
//    printf("System setup Done\r\n");
//
//    printf("\r\n============= Start Interfacing with SD Card =============\r\n");
//
//    FRESULT stat = f_mount(&fatFs, "", 1);
//
//    if (stat == FR_OK) { /* Mount SD */
//
//        printf("SD Card Mount Successful\r\n");
//
//        SD_LED_SetHigh();
//
//if (f_open(&file, "Sd_test.txt", FA_OPEN_ALWAYS | FA_READ | FA_WRITE) == FR_OK) { /* Open or create a file */          
//
//            printf("Create a file successful\r\n");           
//
//if ((file.fsize != 0) && (f_lseek(&file, file.fsize) != FR_OK)) goto endSD; /* Jump to the end of the file */
//
//f_write(&file, "Hello Guys!\r\n", 13, &bw);
//
//            f_write(&file, "This is text message written to SD card. For more information, please visit www.circuitdigest.com\r\n", 99, &bw);
//
//endSD: f_close(&file); /* Close the file */       
//
//            SD_LED_SetLow();
//
//}else{
//
//            printf("Create a file unsuccessful\r\n");
//
//            SD_LED_SetLow();
//
//        }
//
//}else{
//
//        printf("SD Card Mount UnSuccessful\r\n ------ FRESULT %d ------\r\n");
//
//    }
//
//    printf("\r\n============= Finish Interfacing with SD Card ============= \r\n\r\n\r\n\r\n");
//
//while (1) {
//
//// Add your application code
//
//}
//
//}
//
///**
//
// End of File
//
//*/
//
